export interface BlogPost {
  id: string
  title: string
  excerpt: string
  content: string
  author: string
  date: string
  tags: string[]
  readTime: string
  published: boolean
}

// This is a simple in-memory data store
// In production, this would be replaced with a database or CMS
const blogPosts: BlogPost[] = [
  {
    id: "1",
    title: "The Journey of Building Multiple Ventures",
    excerpt: "Reflections on entrepreneurship, failure, and the courage to keep building despite the odds.",
    content: `
# The Journey of Building Multiple Ventures

Starting a business is never easy. Starting multiple businesses simultaneously? That's a whole different challenge. But it's a challenge I've embraced wholeheartedly.

## Why Multiple Ventures?

Many people ask me why I don't focus on just one business. The answer is simple: each venture serves a different purpose and fulfills a different passion. CyberSec Bangladesh allows me to work in technology and security, Blazemark lets me express creativity through fashion, Swader Bari connects me to my cultural roots, and the Forum of Liberal Volunteers enables me to give back to my community.

## The Challenges

Managing multiple ventures requires exceptional time management, delegation, and the ability to context-switch rapidly. There are days when I'm working on a security audit in the morning, reviewing fashion designs in the afternoon, and planning a community event in the evening.

## The Rewards

Despite the challenges, the rewards are immense. Each venture teaches me something new, and the skills I develop in one area often transfer to others. The diversity keeps me energized and constantly learning.

## Advice for Aspiring Entrepreneurs

If you're thinking about starting your own venture, my advice is simple: start. Don't wait for the perfect moment or the perfect idea. Take action, learn from your mistakes, and keep moving forward.
    `,
    author: "Raian Rashid",
    date: "2024-11-15",
    tags: ["Business", "Entrepreneurship", "Motivation"],
    readTime: "5 min read",
    published: true,
  },
  {
    id: "2",
    title: "Cybersecurity in Bangladesh: Challenges and Opportunities",
    excerpt:
      "Exploring the current state of cybersecurity in Bangladesh and the opportunities for growth and innovation.",
    content: `
# Cybersecurity in Bangladesh: Challenges and Opportunities

As Bangladesh continues its digital transformation, cybersecurity has become more critical than ever. Through CyberSec Bangladesh, I've had the opportunity to work with businesses and individuals to improve their security posture.

## The Current Landscape

Bangladesh is experiencing rapid digitalization, with more businesses moving online and more citizens accessing digital services. However, cybersecurity awareness and infrastructure haven't kept pace with this growth.

## Key Challenges

1. **Lack of Awareness**: Many businesses don't understand the importance of cybersecurity until they experience a breach.
2. **Skills Gap**: There's a shortage of trained cybersecurity professionals in the country.
3. **Resource Constraints**: Small and medium businesses often lack the budget for proper security measures.

## Opportunities for Growth

Despite these challenges, I see tremendous opportunities. The growing awareness of cyber threats is creating demand for security services, training, and solutions. This is where CyberSec Bangladesh comes in.

## Building a Secure Future

My vision is to make cybersecurity accessible and affordable for all Bangladeshi businesses, regardless of their size. Through education, training, and practical solutions, we can build a more secure digital future for Bangladesh.
    `,
    author: "Raian Rashid",
    date: "2024-10-28",
    tags: ["Cybersecurity", "Technology", "Bangladesh"],
    readTime: "6 min read",
    published: true,
  },
  {
    id: "3",
    title: "Faith, Purpose, and Entrepreneurship",
    excerpt: "How my faith guides my entrepreneurial journey and helps me stay grounded in purpose.",
    content: `
# Faith, Purpose, and Entrepreneurship

Entrepreneurship is often portrayed as a purely rational pursuit—market analysis, business models, growth strategies. But for me, it's deeply intertwined with faith and purpose.

## Finding Purpose

Every venture I start is driven by a sense of purpose beyond profit. Whether it's protecting businesses from cyber threats, creating beautiful fashion, or serving my community, I see my work as a form of service.

## Faith as a Foundation

My faith provides the foundation for how I conduct business. It reminds me to be honest, to treat people fairly, and to remember that success is not just about personal gain but about creating value for others.

## Staying Grounded

In the fast-paced world of entrepreneurship, it's easy to lose sight of what matters. Faith helps me stay grounded, maintain perspective, and remember that true success is measured not just in business metrics but in the positive impact we create.

## A Message to Fellow Entrepreneurs

Whatever your faith or belief system, I encourage you to connect your work to something larger than yourself. When your business has a purpose beyond profit, it becomes more resilient, more meaningful, and ultimately more successful.
    `,
    author: "Raian Rashid",
    date: "2024-10-10",
    tags: ["Faith", "Motivation", "Life"],
    readTime: "4 min read",
    published: true,
  },
]

export function getAllPosts(): BlogPost[] {
  return blogPosts
    .filter((post) => post.published)
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
}

export function getPostById(id: string): BlogPost | undefined {
  return blogPosts.find((post) => post.id === id && post.published)
}

export function getPostsByTag(tag: string): BlogPost[] {
  return blogPosts
    .filter((post) => post.published && post.tags.includes(tag))
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
}

export function getAllTags(): string[] {
  const tags = new Set<string>()
  blogPosts.forEach((post) => {
    if (post.published) {
      post.tags.forEach((tag) => tags.add(tag))
    }
  })
  return Array.from(tags).sort()
}

// Admin functions for CMS functionality
export function createPost(post: Omit<BlogPost, "id">): BlogPost {
  const newPost: BlogPost = {
    ...post,
    id: Date.now().toString(),
  }
  blogPosts.push(newPost)
  return newPost
}

export function updatePost(id: string, updates: Partial<BlogPost>): BlogPost | null {
  const index = blogPosts.findIndex((post) => post.id === id)
  if (index === -1) return null

  blogPosts[index] = { ...blogPosts[index], ...updates }
  return blogPosts[index]
}

export function deletePost(id: string): boolean {
  const index = blogPosts.findIndex((post) => post.id === id)
  if (index === -1) return false

  blogPosts.splice(index, 1)
  return true
}
