"use client"

export interface HomeContent {
  hero: {
    badge: string
    title: string
    titleAccent: string
    description: string
  }
  intro: {
    title: string
    description: string
  }
  ventures: {
    title: string
    subtitle: string
  }
  cta: {
    title: string
    description: string
  }
}

export interface AboutContent {
  hero: {
    title: string
    titleAccent: string
    subtitle: string
  }
  story: string[]
  facts: Array<{
    icon: string
    title: string
    description: string
  }>
  milestones: Array<{
    year: string
    title: string
    description: string
  }>
  vision: {
    title: string
    description: string
    quote: string
  }
}

export interface Venture {
  id: string
  name: string
  tagline: string
  category: string
  icon: string
  description: string
  features: string[]
  technologies: string[]
  status: string
  link: string
  image: string
}

export interface ContactContent {
  hero: {
    title: string
    titleAccent: string
    subtitle: string
  }
  contactInfo: {
    email: string
    phone: string
    location: string
  }
  social: {
    linkedin: string
    github: string
    twitter: string
    instagram: string
  }
  faqs: Array<{
    question: string
    answer: string
  }>
}

export interface SiteContent {
  home: HomeContent
  about: AboutContent
  ventures: Venture[]
  contact: ContactContent
}

const defaultContent: SiteContent = {
  home: {
    hero: {
      badge: "Entrepreneur. Cybersecurity Student. Dream Builder.",
      title: "Building the Future,",
      titleAccent: "One Venture",
      description:
        "I'm Raian Rashid, a Bangladeshi entrepreneur and cybersecurity student at Victoria University, Brisbane. I blend technology, fashion, and social impact to create meaningful ventures.",
    },
    intro: {
      title: "Turning Ideas Into Reality",
      description:
        '"Success is not final, failure is not fatal: it is the courage to continue that counts." This philosophy drives everything I do—from building cybersecurity solutions to launching fashion brands and creating social impact through technology.',
    },
    ventures: {
      title: "My Ventures",
      subtitle: "A diverse portfolio spanning technology, fashion, hospitality, and social impact",
    },
    cta: {
      title: "Let's Build Something Amazing Together",
      description:
        "Whether you're interested in collaboration, have a project in mind, or just want to connect, I'd love to hear from you.",
    },
  },
  about: {
    hero: {
      title: "About",
      titleAccent: "Me",
      subtitle: "Entrepreneur, Student, and Believer in the Power of Dreams",
    },
    story: [
      "I'm Raian Rashid, a Bangladeshi entrepreneur and cybersecurity student currently studying at Victoria University in Brisbane, Australia. My journey is defined by a relentless pursuit of innovation and a deep commitment to creating meaningful impact.",
      "From a young age, I've been fascinated by the intersection of technology, business, and social good. This curiosity led me to found multiple ventures across diverse industries—from cybersecurity and technology to fashion and hospitality. Each venture represents not just a business opportunity, but a chance to solve real problems and create value for communities.",
      "My entrepreneurial philosophy is simple: blend passion with purpose, creativity with strategy, and innovation with impact. Whether I'm developing cybersecurity solutions, designing premium clothing, or organizing community initiatives, I approach every project with the same dedication to excellence and authenticity.",
      "Beyond business, I'm deeply committed to education and social impact. Through the Forum of Liberal Volunteers, I work to create opportunities for underserved communities in Bangladesh. I believe that true success is measured not just by personal achievements, but by the positive change we create in the world around us.",
    ],
    facts: [
      {
        icon: "GraduationCap",
        title: "Education",
        description: "Cybersecurity Student at Victoria University, Brisbane, Australia",
      },
      {
        icon: "MapPin",
        title: "Location",
        description: "Brisbane, Australia (Originally from Bangladesh)",
      },
      {
        icon: "Rocket",
        title: "Ventures",
        description: "Founder of 4+ businesses across tech, fashion, hospitality, and social impact",
      },
      {
        icon: "Target",
        title: "Mission",
        description: "Blending technology, creativity, and social impact to build a better future",
      },
    ],
    milestones: [
      {
        year: "2020",
        title: "Founded Forum of Liberal Volunteers",
        description: "Launched NGO focused on community development and social impact in Bangladesh",
      },
      {
        year: "2021",
        title: "Started Swader Bari",
        description: "Established catering brand bringing authentic Bangladeshi cuisine to events",
      },
      {
        year: "2022",
        title: "Launched Blazemark",
        description: "Created premium clothing brand combining contemporary design with quality",
      },
      {
        year: "2023",
        title: "Founded CyberSec Bangladesh",
        description: "Built cybersecurity education and solutions platform",
      },
      {
        year: "2024",
        title: "Studying at Victoria University",
        description: "Pursuing Cybersecurity degree in Brisbane, Australia",
      },
    ],
    vision: {
      title: "My Vision",
      description:
        "I envision a future where technology empowers communities, entrepreneurship creates opportunities, and innovation drives positive social change. Through my ventures and initiatives, I'm working to bridge the gap between ambition and impact, one project at a time.",
      quote: "The future belongs to those who believe in the beauty of their dreams.",
    },
  },
  ventures: [
    {
      id: "cybersec-bangladesh",
      name: "CyberSec Bangladesh",
      tagline: "Securing Digital Futures",
      category: "Cybersecurity & Technology",
      icon: "Shield",
      description:
        "CyberSec Bangladesh is a comprehensive cybersecurity education and solutions platform dedicated to empowering businesses and individuals with the knowledge and tools to protect their digital assets. We offer training programs, security audits, and consulting services tailored to the Bangladeshi market.",
      features: [
        "Cybersecurity training and certification programs",
        "Security audits and penetration testing",
        "Incident response and threat management",
        "Custom security solutions for businesses",
      ],
      technologies: ["Security", "Education", "Consulting"],
      status: "Active",
      link: "#",
      image: "/cybersecurity-technology-shield.jpg",
    },
    {
      id: "blazemark",
      name: "Blazemark",
      tagline: "Premium Fashion, Redefined",
      category: "Fashion & Lifestyle",
      icon: "Shirt",
      description:
        "Blazemark is a premium clothing brand that combines contemporary design with exceptional quality craftsmanship. We create fashion for the modern individual who values both style and substance, offering a curated collection of apparel that makes a statement.",
      features: [
        "Contemporary streetwear and casual collections",
        "Premium quality fabrics and materials",
        "Sustainable and ethical production practices",
        "Limited edition drops and exclusive designs",
      ],
      technologies: ["Fashion", "E-commerce", "Design"],
      status: "Active",
      link: "#",
      image: "/premium-fashion-clothing-brand.jpg",
    },
    {
      id: "swader-bari",
      name: "Swader Bari",
      tagline: "Authentic Flavors, Memorable Moments",
      category: "Hospitality & Catering",
      icon: "UtensilsCrossed",
      description:
        "Swader Bari brings the rich, authentic flavors of traditional Bangladeshi cuisine to events and celebrations. Our catering service specializes in creating memorable culinary experiences that honor cultural heritage while delighting modern palates.",
      features: [
        "Traditional Bangladeshi cuisine",
        "Custom menu planning for events",
        "Professional catering services",
        "Cultural authenticity with modern presentation",
      ],
      technologies: ["Catering", "Events", "Hospitality"],
      status: "Active",
      link: "#",
      image: "/bangladeshi-food-catering-traditional.jpg",
    },
    {
      id: "forum-liberal-volunteers",
      name: "Forum of Liberal Volunteers",
      tagline: "Building Communities, Creating Change",
      category: "Social Impact & NGO",
      icon: "Users",
      description:
        "Forum of Liberal Volunteers is a non-governmental organization dedicated to community development, education, and creating positive social change in Bangladesh. We work on initiatives that empower underserved communities and create opportunities for growth and development.",
      features: [
        "Community development programs",
        "Educational initiatives and scholarships",
        "Youth empowerment and leadership training",
        "Social welfare and humanitarian projects",
      ],
      technologies: ["NGO", "Education", "Community"],
      status: "Active",
      link: "#",
      image: "/community-volunteers-social-impact.jpg",
    },
  ],
  contact: {
    hero: {
      title: "Get in",
      titleAccent: "Touch",
      subtitle: "Let's connect and explore opportunities together",
    },
    contactInfo: {
      email: "raian@example.com",
      phone: "+61 XXX XXX XXX",
      location: "Brisbane, Australia",
    },
    social: {
      linkedin: "https://linkedin.com/in/raianrashid",
      github: "https://github.com/raianrashid",
      twitter: "https://twitter.com/raianrashid",
      instagram: "https://instagram.com/raianrashid",
    },
    faqs: [
      {
        question: "What services do you offer?",
        answer:
          "I offer consulting services in cybersecurity, entrepreneurship mentorship, and collaboration opportunities across my various ventures including technology, fashion, and social impact initiatives.",
      },
      {
        question: "Are you available for speaking engagements?",
        answer:
          "Yes! I'm available for speaking engagements on topics including entrepreneurship, cybersecurity, youth empowerment, and building social impact ventures.",
      },
      {
        question: "How can I collaborate with your ventures?",
        answer:
          "I'm always open to partnerships and collaborations. Please reach out via the contact form with details about your proposal, and I'll get back to you as soon as possible.",
      },
      {
        question: "Do you offer mentorship?",
        answer:
          "I'm passionate about helping aspiring entrepreneurs. While my time is limited, I do offer selective mentorship opportunities. Reach out to discuss your goals and how I might be able to help.",
      },
    ],
  },
}

export function getSiteContent(): SiteContent {
  if (typeof window === "undefined") return defaultContent

  const stored = localStorage.getItem("siteContent")
  if (stored) {
    try {
      return JSON.parse(stored)
    } catch {
      return defaultContent
    }
  }
  return defaultContent
}

export function setSiteContent(content: SiteContent) {
  if (typeof window === "undefined") return
  localStorage.setItem("siteContent", JSON.stringify(content))
}

export function getHomeContent(): HomeContent {
  return getSiteContent().home
}

export function setHomeContent(content: HomeContent) {
  const siteContent = getSiteContent()
  siteContent.home = content
  setSiteContent(siteContent)
}

export function getAboutContent(): AboutContent {
  return getSiteContent().about
}

export function setAboutContent(content: AboutContent) {
  const siteContent = getSiteContent()
  siteContent.about = content
  setSiteContent(siteContent)
}

export function getVentures(): Venture[] {
  return getSiteContent().ventures
}

export function setVentures(ventures: Venture[]) {
  const siteContent = getSiteContent()
  siteContent.ventures = ventures
  setSiteContent(siteContent)
}

export function getContactContent(): ContactContent {
  return getSiteContent().contact
}

export function setContactContent(content: ContactContent) {
  const siteContent = getSiteContent()
  siteContent.contact = content
  setSiteContent(siteContent)
}
