"use client"

import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { Card } from "@/components/ui/card"
import { GraduationCap, MapPin, Rocket, Target } from "lucide-react"
import Image from "next/image"
import { useEffect, useState } from "react"
import { getAboutContent, type AboutContent } from "@/lib/cms-data"

export default function AboutPage() {
  const [content, setContent] = useState<AboutContent | null>(null)

  useEffect(() => {
    setContent(getAboutContent())
  }, [])

  if (!content) return null

  const iconMap: Record<string, any> = {
    GraduationCap,
    MapPin,
    Rocket,
    Target,
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />

      <main className="flex-1 pt-16">
        {/* Hero Section */}
        <section className="py-20 md:py-28">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-4xl mx-auto">
              <div className="text-center space-y-6 mb-12">
                <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight text-balance">
                  {content.hero.title} <span className="text-accent">{content.hero.titleAccent}</span>
                </h1>
                <p className="text-xl text-muted-foreground leading-relaxed">{content.hero.subtitle}</p>
              </div>

              <div className="relative w-48 h-48 mx-auto mb-12 rounded-full overflow-hidden border-4 border-accent/20">
                <Image src="/professional-portrait.png" alt="Raian Rashid" fill className="object-cover" />
              </div>

              <div className="prose prose-lg max-w-none space-y-6 text-muted-foreground leading-relaxed">
                {content.story.map((paragraph, index) => (
                  <p key={index} className="text-lg">
                    {paragraph}
                  </p>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Quick Facts */}
        <section className="py-20 bg-card">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-4xl mx-auto">
              <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">Quick Facts</h2>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {content.facts.map((fact, index) => {
                  const Icon = iconMap[fact.icon] || Target
                  return (
                    <Card key={index} className="p-6 space-y-3 border-border hover:border-accent/50 transition-colors">
                      <div className="flex items-center gap-3">
                        <div className="p-2 rounded-lg bg-accent/10 text-accent">
                          <Icon className="h-5 w-5" />
                        </div>
                        <h3 className="font-semibold">{fact.title}</h3>
                      </div>
                      <p className="text-muted-foreground leading-relaxed">{fact.description}</p>
                    </Card>
                  )
                })}
              </div>
            </div>
          </div>
        </section>

        {/* Timeline */}
        <section className="py-20 md:py-28">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-4xl mx-auto">
              <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">My Journey</h2>

              <div className="space-y-8">
                {content.milestones.map((milestone, index) => (
                  <div key={index} className="flex gap-6 group">
                    <div className="flex flex-col items-center">
                      <div className="flex h-10 w-10 items-center justify-center rounded-full border-2 border-accent bg-background text-accent font-bold text-sm group-hover:bg-accent group-hover:text-accent-foreground transition-colors">
                        {milestone.year.slice(-2)}
                      </div>
                      {index !== content.milestones.length - 1 && (
                        <div className="w-px h-full bg-border group-hover:bg-accent/50 transition-colors" />
                      )}
                    </div>
                    <div className="flex-1 pb-8">
                      <div className="space-y-2">
                        <div className="text-sm text-accent font-semibold">{milestone.year}</div>
                        <h3 className="text-xl font-semibold">{milestone.title}</h3>
                        <p className="text-muted-foreground leading-relaxed">{milestone.description}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Vision Section */}
        <section className="py-20 bg-card">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-3xl mx-auto text-center space-y-6">
              <h2 className="text-3xl md:text-4xl font-bold text-balance">{content.vision.title}</h2>
              <p className="text-lg text-muted-foreground leading-relaxed text-pretty">{content.vision.description}</p>
              <blockquote className="text-xl font-medium italic text-foreground pt-6 border-t border-border/40 mt-8">
                "{content.vision.quote}"
              </blockquote>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
