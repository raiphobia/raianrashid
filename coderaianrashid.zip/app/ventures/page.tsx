"use client"

import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ExternalLink, Shield, Shirt, UtensilsCrossed, Users, Briefcase } from "lucide-react"
import Image from "next/image"
import { useEffect, useState } from "react"
import { getVentures, type Venture } from "@/lib/cms-data"

export default function VenturesPage() {
  const [ventures, setVentures] = useState<Venture[]>([])

  useEffect(() => {
    setVentures(getVentures())
  }, [])

  const iconMap: Record<string, any> = {
    Shield,
    Shirt,
    UtensilsCrossed,
    Users,
    Briefcase,
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />

      <main className="flex-1 pt-16">
        {/* Hero Section */}
        <section className="py-20 md:py-28 bg-gradient-to-br from-accent/5 via-background to-background">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-4xl mx-auto text-center space-y-6">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight text-balance">
                My <span className="text-accent">Ventures</span>
              </h1>
              <p className="text-xl text-muted-foreground leading-relaxed text-pretty">
                A diverse portfolio spanning technology, fashion, hospitality, and social impact. Each venture
                represents a commitment to excellence and meaningful innovation.
              </p>
            </div>
          </div>
        </section>

        {/* Ventures Grid */}
        <section className="py-20">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="space-y-20">
              {ventures.map((venture, index) => {
                const Icon = iconMap[venture.icon] || Briefcase
                return (
                  <div
                    key={venture.id}
                    className={`flex flex-col ${
                      index % 2 === 0 ? "lg:flex-row" : "lg:flex-row-reverse"
                    } gap-8 lg:gap-12 items-center`}
                  >
                    <div className="w-full lg:w-1/2">
                      <div className="relative aspect-[3/2] rounded-xl overflow-hidden border border-border shadow-lg">
                        <Image
                          src={venture.image || "/placeholder.svg"}
                          alt={venture.name}
                          fill
                          className="object-cover"
                        />
                      </div>
                    </div>

                    <div className="w-full lg:w-1/2 space-y-6">
                      <div className="space-y-3">
                        <div className="flex items-center gap-3">
                          <div className="p-2 rounded-lg bg-accent/10 text-accent">
                            <Icon className="h-6 w-6" />
                          </div>
                          <Badge variant="secondary">{venture.category}</Badge>
                        </div>

                        <h2 className="text-3xl md:text-4xl font-bold">{venture.name}</h2>
                        <p className="text-lg text-accent font-medium">{venture.tagline}</p>
                      </div>

                      <p className="text-muted-foreground leading-relaxed">{venture.description}</p>

                      <div className="space-y-3">
                        <h3 className="font-semibold text-sm uppercase tracking-wide">Key Features</h3>
                        <ul className="space-y-2">
                          {venture.features.map((feature, idx) => (
                            <li key={idx} className="flex items-start gap-2 text-sm text-muted-foreground">
                              <span className="text-accent mt-1">•</span>
                              <span>{feature}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      <div className="flex flex-wrap gap-2">
                        {venture.technologies.map((tech) => (
                          <Badge key={tech} variant="outline" className="text-xs">
                            {tech}
                          </Badge>
                        ))}
                      </div>

                      <div className="flex items-center gap-3 pt-2">
                        <Badge className="bg-accent/10 text-accent hover:bg-accent/20 border-accent/20">
                          {venture.status}
                        </Badge>
                        <Button variant="outline" size="sm" className="group bg-transparent" asChild>
                          <a href={venture.link} target="_blank" rel="noopener noreferrer">
                            Learn More
                            <ExternalLink className="ml-2 h-3 w-3 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
                          </a>
                        </Button>
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-card">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-3xl mx-auto text-center space-y-6">
              <h2 className="text-3xl md:text-4xl font-bold text-balance">Interested in Collaboration?</h2>
              <p className="text-lg text-muted-foreground leading-relaxed">
                I'm always open to new opportunities, partnerships, and innovative projects. Let's connect and explore
                how we can work together.
              </p>
              <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground" asChild>
                <a href="/contact">Get in Touch</a>
              </Button>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
