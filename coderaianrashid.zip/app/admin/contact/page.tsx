"use client"

import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card } from "@/components/ui/card"
import { ArrowLeft, Save, Plus, Trash2 } from "lucide-react"
import Link from "next/link"
import { useState, useEffect } from "react"
import { getContactContent, setContactContent, type ContactContent } from "@/lib/cms-data"
import { useToast } from "@/hooks/use-toast"

export default function AdminContactPage() {
  const [content, setContent] = useState<ContactContent | null>(null)
  const { toast } = useToast()

  useEffect(() => {
    setContent(getContactContent())
  }, [])

  const handleSave = () => {
    if (content) {
      setContactContent(content)
      toast({
        title: "Saved successfully",
        description: "Contact page content has been updated",
      })
    }
  }

  if (!content) return null

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />

      <main className="flex-1 pt-16">
        <section className="py-12">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-3xl mx-auto">
              <div className="flex items-center justify-between mb-8">
                <div>
                  <Link
                    href="/admin"
                    className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground mb-2"
                  >
                    <ArrowLeft className="h-4 w-4 mr-1" />
                    Back to Admin
                  </Link>
                  <h1 className="text-3xl font-bold">Edit Contact Page</h1>
                </div>
                <Button onClick={handleSave} className="gap-2">
                  <Save className="h-4 w-4" />
                  Save Changes
                </Button>
              </div>

              <div className="space-y-8">
                {/* Hero Section */}
                <Card className="p-6 space-y-4">
                  <h2 className="text-xl font-semibold">Hero Section</h2>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Title (First Part)</Label>
                      <Input
                        value={content.hero.title}
                        onChange={(e) =>
                          setContent({
                            ...content,
                            hero: { ...content.hero, title: e.target.value },
                          })
                        }
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>Title (Accent Part)</Label>
                      <Input
                        value={content.hero.titleAccent}
                        onChange={(e) =>
                          setContent({
                            ...content,
                            hero: { ...content.hero, titleAccent: e.target.value },
                          })
                        }
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Subtitle</Label>
                    <Input
                      value={content.hero.subtitle}
                      onChange={(e) =>
                        setContent({
                          ...content,
                          hero: { ...content.hero, subtitle: e.target.value },
                        })
                      }
                    />
                  </div>
                </Card>

                {/* Contact Info */}
                <Card className="p-6 space-y-4">
                  <h2 className="text-xl font-semibold">Contact Information</h2>

                  <div className="space-y-2">
                    <Label>Email</Label>
                    <Input
                      type="email"
                      value={content.contactInfo.email}
                      onChange={(e) =>
                        setContent({
                          ...content,
                          contactInfo: { ...content.contactInfo, email: e.target.value },
                        })
                      }
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Phone</Label>
                    <Input
                      value={content.contactInfo.phone}
                      onChange={(e) =>
                        setContent({
                          ...content,
                          contactInfo: { ...content.contactInfo, phone: e.target.value },
                        })
                      }
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Location</Label>
                    <Input
                      value={content.contactInfo.location}
                      onChange={(e) =>
                        setContent({
                          ...content,
                          contactInfo: { ...content.contactInfo, location: e.target.value },
                        })
                      }
                    />
                  </div>
                </Card>

                {/* Social Links */}
                <Card className="p-6 space-y-4">
                  <h2 className="text-xl font-semibold">Social Media Links</h2>

                  <div className="space-y-2">
                    <Label>LinkedIn</Label>
                    <Input
                      value={content.social.linkedin}
                      onChange={(e) =>
                        setContent({
                          ...content,
                          social: { ...content.social, linkedin: e.target.value },
                        })
                      }
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>GitHub</Label>
                    <Input
                      value={content.social.github}
                      onChange={(e) =>
                        setContent({
                          ...content,
                          social: { ...content.social, github: e.target.value },
                        })
                      }
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Twitter</Label>
                    <Input
                      value={content.social.twitter}
                      onChange={(e) =>
                        setContent({
                          ...content,
                          social: { ...content.social, twitter: e.target.value },
                        })
                      }
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Instagram</Label>
                    <Input
                      value={content.social.instagram}
                      onChange={(e) =>
                        setContent({
                          ...content,
                          social: { ...content.social, instagram: e.target.value },
                        })
                      }
                    />
                  </div>
                </Card>

                {/* FAQs */}
                <Card className="p-6 space-y-4">
                  <div className="flex items-center justify-between">
                    <h2 className="text-xl font-semibold">FAQs</h2>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() =>
                        setContent({
                          ...content,
                          faqs: [...content.faqs, { question: "", answer: "" }],
                        })
                      }
                    >
                      <Plus className="h-4 w-4 mr-1" />
                      Add FAQ
                    </Button>
                  </div>

                  {content.faqs.map((faq, index) => (
                    <div key={index} className="p-4 border rounded-lg space-y-3">
                      <div className="flex items-center justify-between">
                        <Label className="font-semibold">FAQ {index + 1}</Label>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() =>
                            setContent({
                              ...content,
                              faqs: content.faqs.filter((_, i) => i !== index),
                            })
                          }
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>

                      <div className="space-y-2">
                        <Label className="text-xs">Question</Label>
                        <Input
                          value={faq.question}
                          onChange={(e) => {
                            const newFaqs = [...content.faqs]
                            newFaqs[index].question = e.target.value
                            setContent({ ...content, faqs: newFaqs })
                          }}
                        />
                      </div>

                      <div className="space-y-2">
                        <Label className="text-xs">Answer</Label>
                        <Textarea
                          rows={3}
                          value={faq.answer}
                          onChange={(e) => {
                            const newFaqs = [...content.faqs]
                            newFaqs[index].answer = e.target.value
                            setContent({ ...content, faqs: newFaqs })
                          }}
                        />
                      </div>
                    </div>
                  ))}
                </Card>

                <div className="flex justify-end">
                  <Button onClick={handleSave} size="lg" className="gap-2">
                    <Save className="h-4 w-4" />
                    Save All Changes
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
