"use client"

import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card } from "@/components/ui/card"
import { ArrowLeft, Save } from "lucide-react"
import Link from "next/link"
import { useState, useEffect } from "react"
import { getHomeContent, setHomeContent, type HomeContent } from "@/lib/cms-data"
import { useToast } from "@/hooks/use-toast"

export default function AdminHomePage() {
  const [content, setContent] = useState<HomeContent | null>(null)
  const { toast } = useToast()

  useEffect(() => {
    setContent(getHomeContent())
  }, [])

  const handleSave = () => {
    if (content) {
      setHomeContent(content)
      toast({
        title: "Saved successfully",
        description: "Home page content has been updated",
      })
    }
  }

  if (!content) return null

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />

      <main className="flex-1 pt-16">
        <section className="py-12">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-3xl mx-auto">
              <div className="flex items-center justify-between mb-8">
                <div>
                  <Link
                    href="/admin"
                    className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground mb-2"
                  >
                    <ArrowLeft className="h-4 w-4 mr-1" />
                    Back to Admin
                  </Link>
                  <h1 className="text-3xl font-bold">Edit Home Page</h1>
                </div>
                <Button onClick={handleSave} className="gap-2">
                  <Save className="h-4 w-4" />
                  Save Changes
                </Button>
              </div>

              <div className="space-y-8">
                {/* Hero Section */}
                <Card className="p-6 space-y-4">
                  <h2 className="text-xl font-semibold">Hero Section</h2>

                  <div className="space-y-2">
                    <Label htmlFor="hero-badge">Badge Text</Label>
                    <Input
                      id="hero-badge"
                      value={content.hero.badge}
                      onChange={(e) =>
                        setContent({
                          ...content,
                          hero: { ...content.hero, badge: e.target.value },
                        })
                      }
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="hero-title">Title (First Part)</Label>
                    <Input
                      id="hero-title"
                      value={content.hero.title}
                      onChange={(e) =>
                        setContent({
                          ...content,
                          hero: { ...content.hero, title: e.target.value },
                        })
                      }
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="hero-accent">Title (Accent Part)</Label>
                    <Input
                      id="hero-accent"
                      value={content.hero.titleAccent}
                      onChange={(e) =>
                        setContent({
                          ...content,
                          hero: { ...content.hero, titleAccent: e.target.value },
                        })
                      }
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="hero-description">Description</Label>
                    <Textarea
                      id="hero-description"
                      rows={4}
                      value={content.hero.description}
                      onChange={(e) =>
                        setContent({
                          ...content,
                          hero: { ...content.hero, description: e.target.value },
                        })
                      }
                    />
                  </div>
                </Card>

                {/* Intro Section */}
                <Card className="p-6 space-y-4">
                  <h2 className="text-xl font-semibold">Intro Section</h2>

                  <div className="space-y-2">
                    <Label htmlFor="intro-title">Title</Label>
                    <Input
                      id="intro-title"
                      value={content.intro.title}
                      onChange={(e) =>
                        setContent({
                          ...content,
                          intro: { ...content.intro, title: e.target.value },
                        })
                      }
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="intro-description">Description</Label>
                    <Textarea
                      id="intro-description"
                      rows={4}
                      value={content.intro.description}
                      onChange={(e) =>
                        setContent({
                          ...content,
                          intro: { ...content.intro, description: e.target.value },
                        })
                      }
                    />
                  </div>
                </Card>

                {/* Ventures Section */}
                <Card className="p-6 space-y-4">
                  <h2 className="text-xl font-semibold">Ventures Section</h2>

                  <div className="space-y-2">
                    <Label htmlFor="ventures-title">Title</Label>
                    <Input
                      id="ventures-title"
                      value={content.ventures.title}
                      onChange={(e) =>
                        setContent({
                          ...content,
                          ventures: { ...content.ventures, title: e.target.value },
                        })
                      }
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="ventures-subtitle">Subtitle</Label>
                    <Input
                      id="ventures-subtitle"
                      value={content.ventures.subtitle}
                      onChange={(e) =>
                        setContent({
                          ...content,
                          ventures: { ...content.ventures, subtitle: e.target.value },
                        })
                      }
                    />
                  </div>
                </Card>

                {/* CTA Section */}
                <Card className="p-6 space-y-4">
                  <h2 className="text-xl font-semibold">Call-to-Action Section</h2>

                  <div className="space-y-2">
                    <Label htmlFor="cta-title">Title</Label>
                    <Input
                      id="cta-title"
                      value={content.cta.title}
                      onChange={(e) =>
                        setContent({
                          ...content,
                          cta: { ...content.cta, title: e.target.value },
                        })
                      }
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="cta-description">Description</Label>
                    <Textarea
                      id="cta-description"
                      rows={3}
                      value={content.cta.description}
                      onChange={(e) =>
                        setContent({
                          ...content,
                          cta: { ...content.cta, description: e.target.value },
                        })
                      }
                    />
                  </div>
                </Card>

                <div className="flex justify-end">
                  <Button onClick={handleSave} size="lg" className="gap-2">
                    <Save className="h-4 w-4" />
                    Save All Changes
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
