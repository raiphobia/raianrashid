"use client"

import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card } from "@/components/ui/card"
import { ArrowLeft, Save, Plus, Trash2 } from "lucide-react"
import Link from "next/link"
import { useState, useEffect } from "react"
import { getAboutContent, setAboutContent, type AboutContent } from "@/lib/cms-data"
import { useToast } from "@/hooks/use-toast"

export default function AdminAboutPage() {
  const [content, setContent] = useState<AboutContent | null>(null)
  const { toast } = useToast()

  useEffect(() => {
    setContent(getAboutContent())
  }, [])

  const handleSave = () => {
    if (content) {
      setAboutContent(content)
      toast({
        title: "Saved successfully",
        description: "About page content has been updated",
      })
    }
  }

  if (!content) return null

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />

      <main className="flex-1 pt-16">
        <section className="py-12">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-3xl mx-auto">
              <div className="flex items-center justify-between mb-8">
                <div>
                  <Link
                    href="/admin"
                    className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground mb-2"
                  >
                    <ArrowLeft className="h-4 w-4 mr-1" />
                    Back to Admin
                  </Link>
                  <h1 className="text-3xl font-bold">Edit About Page</h1>
                </div>
                <Button onClick={handleSave} className="gap-2">
                  <Save className="h-4 w-4" />
                  Save Changes
                </Button>
              </div>

              <div className="space-y-8">
                {/* Hero Section */}
                <Card className="p-6 space-y-4">
                  <h2 className="text-xl font-semibold">Hero Section</h2>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Title (First Part)</Label>
                      <Input
                        value={content.hero.title}
                        onChange={(e) =>
                          setContent({
                            ...content,
                            hero: { ...content.hero, title: e.target.value },
                          })
                        }
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>Title (Accent Part)</Label>
                      <Input
                        value={content.hero.titleAccent}
                        onChange={(e) =>
                          setContent({
                            ...content,
                            hero: { ...content.hero, titleAccent: e.target.value },
                          })
                        }
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Subtitle</Label>
                    <Input
                      value={content.hero.subtitle}
                      onChange={(e) =>
                        setContent({
                          ...content,
                          hero: { ...content.hero, subtitle: e.target.value },
                        })
                      }
                    />
                  </div>
                </Card>

                {/* Story Paragraphs */}
                <Card className="p-6 space-y-4">
                  <div className="flex items-center justify-between">
                    <h2 className="text-xl font-semibold">Story Paragraphs</h2>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() =>
                        setContent({
                          ...content,
                          story: [...content.story, ""],
                        })
                      }
                    >
                      <Plus className="h-4 w-4 mr-1" />
                      Add Paragraph
                    </Button>
                  </div>

                  {content.story.map((paragraph, index) => (
                    <div key={index} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <Label>Paragraph {index + 1}</Label>
                        {content.story.length > 1 && (
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() =>
                              setContent({
                                ...content,
                                story: content.story.filter((_, i) => i !== index),
                              })
                            }
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                      <Textarea
                        rows={4}
                        value={paragraph}
                        onChange={(e) => {
                          const newStory = [...content.story]
                          newStory[index] = e.target.value
                          setContent({ ...content, story: newStory })
                        }}
                      />
                    </div>
                  ))}
                </Card>

                {/* Quick Facts */}
                <Card className="p-6 space-y-4">
                  <h2 className="text-xl font-semibold">Quick Facts</h2>

                  {content.facts.map((fact, index) => (
                    <div key={index} className="p-4 border rounded-lg space-y-3">
                      <div className="flex items-center justify-between">
                        <Label className="font-semibold">Fact {index + 1}</Label>
                      </div>

                      <div className="grid grid-cols-2 gap-3">
                        <div className="space-y-2">
                          <Label className="text-xs">Icon Name</Label>
                          <Input
                            value={fact.icon}
                            onChange={(e) => {
                              const newFacts = [...content.facts]
                              newFacts[index].icon = e.target.value
                              setContent({ ...content, facts: newFacts })
                            }}
                            placeholder="e.g., GraduationCap"
                          />
                        </div>

                        <div className="space-y-2">
                          <Label className="text-xs">Title</Label>
                          <Input
                            value={fact.title}
                            onChange={(e) => {
                              const newFacts = [...content.facts]
                              newFacts[index].title = e.target.value
                              setContent({ ...content, facts: newFacts })
                            }}
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label className="text-xs">Description</Label>
                        <Textarea
                          rows={2}
                          value={fact.description}
                          onChange={(e) => {
                            const newFacts = [...content.facts]
                            newFacts[index].description = e.target.value
                            setContent({ ...content, facts: newFacts })
                          }}
                        />
                      </div>
                    </div>
                  ))}
                </Card>

                {/* Milestones */}
                <Card className="p-6 space-y-4">
                  <div className="flex items-center justify-between">
                    <h2 className="text-xl font-semibold">Timeline Milestones</h2>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() =>
                        setContent({
                          ...content,
                          milestones: [...content.milestones, { year: "", title: "", description: "" }],
                        })
                      }
                    >
                      <Plus className="h-4 w-4 mr-1" />
                      Add Milestone
                    </Button>
                  </div>

                  {content.milestones.map((milestone, index) => (
                    <div key={index} className="p-4 border rounded-lg space-y-3">
                      <div className="flex items-center justify-between">
                        <Label className="font-semibold">Milestone {index + 1}</Label>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() =>
                            setContent({
                              ...content,
                              milestones: content.milestones.filter((_, i) => i !== index),
                            })
                          }
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>

                      <div className="grid grid-cols-2 gap-3">
                        <div className="space-y-2">
                          <Label className="text-xs">Year</Label>
                          <Input
                            value={milestone.year}
                            onChange={(e) => {
                              const newMilestones = [...content.milestones]
                              newMilestones[index].year = e.target.value
                              setContent({ ...content, milestones: newMilestones })
                            }}
                          />
                        </div>

                        <div className="space-y-2">
                          <Label className="text-xs">Title</Label>
                          <Input
                            value={milestone.title}
                            onChange={(e) => {
                              const newMilestones = [...content.milestones]
                              newMilestones[index].title = e.target.value
                              setContent({ ...content, milestones: newMilestones })
                            }}
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label className="text-xs">Description</Label>
                        <Textarea
                          rows={2}
                          value={milestone.description}
                          onChange={(e) => {
                            const newMilestones = [...content.milestones]
                            newMilestones[index].description = e.target.value
                            setContent({ ...content, milestones: newMilestones })
                          }}
                        />
                      </div>
                    </div>
                  ))}
                </Card>

                {/* Vision Section */}
                <Card className="p-6 space-y-4">
                  <h2 className="text-xl font-semibold">Vision Section</h2>

                  <div className="space-y-2">
                    <Label>Title</Label>
                    <Input
                      value={content.vision.title}
                      onChange={(e) =>
                        setContent({
                          ...content,
                          vision: { ...content.vision, title: e.target.value },
                        })
                      }
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Description</Label>
                    <Textarea
                      rows={4}
                      value={content.vision.description}
                      onChange={(e) =>
                        setContent({
                          ...content,
                          vision: { ...content.vision, description: e.target.value },
                        })
                      }
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Quote</Label>
                    <Input
                      value={content.vision.quote}
                      onChange={(e) =>
                        setContent({
                          ...content,
                          vision: { ...content.vision, quote: e.target.value },
                        })
                      }
                    />
                  </div>
                </Card>

                <div className="flex justify-end">
                  <Button onClick={handleSave} size="lg" className="gap-2">
                    <Save className="h-4 w-4" />
                    Save All Changes
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
