import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { Card } from "@/components/ui/card"
import { Home, User, Briefcase, Mail, FileText, ArrowRight } from "lucide-react"
import Link from "next/link"

export default function AdminPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />

      <main className="flex-1 pt-16">
        <section className="py-20 md:py-28">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-4xl mx-auto">
              <div className="text-center space-y-4 mb-12">
                <h1 className="text-4xl md:text-5xl font-bold">Content Management</h1>
                <p className="text-xl text-muted-foreground">
                  Edit all website content without coding - simple forms for everything
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Link href="/admin/home">
                  <Card className="p-6 hover:border-accent/50 transition-all cursor-pointer group">
                    <div className="flex items-start gap-4">
                      <div className="p-3 rounded-lg bg-accent/10 text-accent">
                        <Home className="h-6 w-6" />
                      </div>
                      <div className="flex-1 space-y-2">
                        <h3 className="text-xl font-semibold group-hover:text-accent transition-colors">Home Page</h3>
                        <p className="text-muted-foreground text-sm">
                          Edit hero section, intro text, and call-to-action content
                        </p>
                        <div className="flex items-center text-accent text-sm font-medium pt-2">
                          Edit Content
                          <ArrowRight className="ml-1 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                        </div>
                      </div>
                    </div>
                  </Card>
                </Link>

                <Link href="/admin/about">
                  <Card className="p-6 hover:border-accent/50 transition-all cursor-pointer group">
                    <div className="flex items-start gap-4">
                      <div className="p-3 rounded-lg bg-accent/10 text-accent">
                        <User className="h-6 w-6" />
                      </div>
                      <div className="flex-1 space-y-2">
                        <h3 className="text-xl font-semibold group-hover:text-accent transition-colors">About Page</h3>
                        <p className="text-muted-foreground text-sm">
                          Edit story, timeline, quick facts, and vision statement
                        </p>
                        <div className="flex items-center text-accent text-sm font-medium pt-2">
                          Edit Content
                          <ArrowRight className="ml-1 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                        </div>
                      </div>
                    </div>
                  </Card>
                </Link>

                <Link href="/admin/ventures">
                  <Card className="p-6 hover:border-accent/50 transition-all cursor-pointer group">
                    <div className="flex items-start gap-4">
                      <div className="p-3 rounded-lg bg-accent/10 text-accent">
                        <Briefcase className="h-6 w-6" />
                      </div>
                      <div className="flex-1 space-y-2">
                        <h3 className="text-xl font-semibold group-hover:text-accent transition-colors">Ventures</h3>
                        <p className="text-muted-foreground text-sm">Add, edit, or remove ventures and their details</p>
                        <div className="flex items-center text-accent text-sm font-medium pt-2">
                          Edit Content
                          <ArrowRight className="ml-1 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                        </div>
                      </div>
                    </div>
                  </Card>
                </Link>

                <Link href="/admin/contact">
                  <Card className="p-6 hover:border-accent/50 transition-all cursor-pointer group">
                    <div className="flex items-start gap-4">
                      <div className="p-3 rounded-lg bg-accent/10 text-accent">
                        <Mail className="h-6 w-6" />
                      </div>
                      <div className="flex-1 space-y-2">
                        <h3 className="text-xl font-semibold group-hover:text-accent transition-colors">
                          Contact Page
                        </h3>
                        <p className="text-muted-foreground text-sm">
                          Edit contact information, social links, and FAQs
                        </p>
                        <div className="flex items-center text-accent text-sm font-medium pt-2">
                          Edit Content
                          <ArrowRight className="ml-1 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                        </div>
                      </div>
                    </div>
                  </Card>
                </Link>

                <Link href="/admin/blog">
                  <Card className="p-6 hover:border-accent/50 transition-all cursor-pointer group">
                    <div className="flex items-start gap-4">
                      <div className="p-3 rounded-lg bg-accent/10 text-accent">
                        <FileText className="h-6 w-6" />
                      </div>
                      <div className="flex-1 space-y-2">
                        <h3 className="text-xl font-semibold group-hover:text-accent transition-colors">Blog Posts</h3>
                        <p className="text-muted-foreground text-sm">Create, edit, and manage blog posts</p>
                        <div className="flex items-center text-accent text-sm font-medium pt-2">
                          Edit Content
                          <ArrowRight className="ml-1 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                        </div>
                      </div>
                    </div>
                  </Card>
                </Link>
              </div>

              <div className="mt-12 p-6 rounded-xl bg-accent/5 border border-accent/20">
                <h3 className="font-semibold mb-2">How it works</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  All changes are saved automatically to your browser's local storage. To make changes permanent across
                  devices, you can connect a database integration like Supabase or Neon from the sidebar.
                </p>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
