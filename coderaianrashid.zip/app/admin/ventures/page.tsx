"use client"

import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card } from "@/components/ui/card"
import { ArrowLeft, Save, Plus, Trash2 } from "lucide-react"
import Link from "next/link"
import { useState, useEffect } from "react"
import { getVentures, setVentures, type Venture } from "@/lib/cms-data"
import { useToast } from "@/hooks/use-toast"

export default function AdminVenturesPage() {
  const [ventures, setVenturesState] = useState<Venture[]>([])
  const { toast } = useToast()

  useEffect(() => {
    setVenturesState(getVentures())
  }, [])

  const handleSave = () => {
    setVentures(ventures)
    toast({
      title: "Saved successfully",
      description: "Ventures have been updated",
    })
  }

  const addVenture = () => {
    setVenturesState([
      ...ventures,
      {
        id: `venture-${Date.now()}`,
        name: "",
        tagline: "",
        category: "",
        icon: "Briefcase",
        description: "",
        features: [""],
        technologies: [""],
        status: "Active",
        link: "#",
        image: "/placeholder.svg",
      },
    ])
  }

  const removeVenture = (index: number) => {
    setVenturesState(ventures.filter((_, i) => i !== index))
  }

  const updateVenture = (index: number, field: keyof Venture, value: any) => {
    const newVentures = [...ventures]
    newVentures[index] = { ...newVentures[index], [field]: value }
    setVenturesState(newVentures)
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />

      <main className="flex-1 pt-16">
        <section className="py-12">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-4xl mx-auto">
              <div className="flex items-center justify-between mb-8">
                <div>
                  <Link
                    href="/admin"
                    className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground mb-2"
                  >
                    <ArrowLeft className="h-4 w-4 mr-1" />
                    Back to Admin
                  </Link>
                  <h1 className="text-3xl font-bold">Edit Ventures</h1>
                </div>
                <div className="flex gap-2">
                  <Button onClick={addVenture} variant="outline" className="gap-2 bg-transparent">
                    <Plus className="h-4 w-4" />
                    Add Venture
                  </Button>
                  <Button onClick={handleSave} className="gap-2">
                    <Save className="h-4 w-4" />
                    Save Changes
                  </Button>
                </div>
              </div>

              <div className="space-y-8">
                {ventures.map((venture, index) => (
                  <Card key={venture.id} className="p-6 space-y-4">
                    <div className="flex items-center justify-between">
                      <h2 className="text-xl font-semibold">Venture {index + 1}</h2>
                      <Button size="sm" variant="ghost" onClick={() => removeVenture(index)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>Name</Label>
                        <Input value={venture.name} onChange={(e) => updateVenture(index, "name", e.target.value)} />
                      </div>

                      <div className="space-y-2">
                        <Label>Tagline</Label>
                        <Input
                          value={venture.tagline}
                          onChange={(e) => updateVenture(index, "tagline", e.target.value)}
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>Category</Label>
                        <Input
                          value={venture.category}
                          onChange={(e) => updateVenture(index, "category", e.target.value)}
                        />
                      </div>

                      <div className="space-y-2">
                        <Label>Icon Name</Label>
                        <Input
                          value={venture.icon}
                          onChange={(e) => updateVenture(index, "icon", e.target.value)}
                          placeholder="e.g., Shield, Shirt"
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label>Description</Label>
                      <Textarea
                        rows={4}
                        value={venture.description}
                        onChange={(e) => updateVenture(index, "description", e.target.value)}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>Features (one per line)</Label>
                      <Textarea
                        rows={4}
                        value={venture.features.join("\n")}
                        onChange={(e) => updateVenture(index, "features", e.target.value.split("\n"))}
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>Technologies (comma-separated)</Label>
                        <Input
                          value={venture.technologies.join(", ")}
                          onChange={(e) =>
                            updateVenture(
                              index,
                              "technologies",
                              e.target.value.split(",").map((t) => t.trim()),
                            )
                          }
                        />
                      </div>

                      <div className="space-y-2">
                        <Label>Status</Label>
                        <Input
                          value={venture.status}
                          onChange={(e) => updateVenture(index, "status", e.target.value)}
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>Link</Label>
                        <Input value={venture.link} onChange={(e) => updateVenture(index, "link", e.target.value)} />
                      </div>

                      <div className="space-y-2">
                        <Label>Image URL</Label>
                        <Input value={venture.image} onChange={(e) => updateVenture(index, "image", e.target.value)} />
                      </div>
                    </div>
                  </Card>
                ))}

                {ventures.length === 0 && (
                  <Card className="p-12 text-center">
                    <p className="text-muted-foreground mb-4">No ventures yet. Add your first venture!</p>
                    <Button onClick={addVenture} className="gap-2">
                      <Plus className="h-4 w-4" />
                      Add Venture
                    </Button>
                  </Card>
                )}

                {ventures.length > 0 && (
                  <div className="flex justify-end">
                    <Button onClick={handleSave} size="lg" className="gap-2">
                      <Save className="h-4 w-4" />
                      Save All Changes
                    </Button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
