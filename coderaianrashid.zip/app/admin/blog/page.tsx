"use client"

import { useState } from "react"
import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Plus, Edit, Trash2, Save } from "lucide-react"
import { getAllPosts, type BlogPost } from "@/lib/blog-data"

export default function AdminBlogPage() {
  const [posts, setPosts] = useState(getAllPosts())
  const [isEditing, setIsEditing] = useState(false)
  const [currentPost, setCurrentPost] = useState<Partial<BlogPost>>({
    title: "",
    excerpt: "",
    content: "",
    author: "Raian Rashid",
    date: new Date().toISOString().split("T")[0],
    tags: [],
    readTime: "5 min read",
    published: true,
  })
  const [tagInput, setTagInput] = useState("")

  const handleSave = () => {
    // In a real application, this would call an API to save to a database
    console.log("Saving post:", currentPost)
    alert("Post saved! (This is a demo - in production, this would save to a database)")
    setIsEditing(false)
    setCurrentPost({
      title: "",
      excerpt: "",
      content: "",
      author: "Raian Rashid",
      date: new Date().toISOString().split("T")[0],
      tags: [],
      readTime: "5 min read",
      published: true,
    })
  }

  const handleAddTag = () => {
    if (tagInput.trim() && !currentPost.tags?.includes(tagInput.trim())) {
      setCurrentPost({
        ...currentPost,
        tags: [...(currentPost.tags || []), tagInput.trim()],
      })
      setTagInput("")
    }
  }

  const handleRemoveTag = (tagToRemove: string) => {
    setCurrentPost({
      ...currentPost,
      tags: currentPost.tags?.filter((tag) => tag !== tagToRemove) || [],
    })
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />

      <main className="flex-1 pt-16">
        <section className="py-20">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-5xl mx-auto space-y-8">
              <div className="flex justify-between items-center">
                <h1 className="text-4xl font-bold">Blog Admin</h1>
                <Button onClick={() => setIsEditing(!isEditing)} className="gap-2">
                  <Plus className="h-4 w-4" />
                  New Post
                </Button>
              </div>

              {isEditing && (
                <Card className="p-8 space-y-6">
                  <h2 className="text-2xl font-bold">{currentPost.id ? "Edit Post" : "Create New Post"}</h2>

                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="title">Title</Label>
                      <Input
                        id="title"
                        value={currentPost.title}
                        onChange={(e) => setCurrentPost({ ...currentPost, title: e.target.value })}
                        placeholder="Enter post title"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="excerpt">Excerpt</Label>
                      <Textarea
                        id="excerpt"
                        value={currentPost.excerpt}
                        onChange={(e) => setCurrentPost({ ...currentPost, excerpt: e.target.value })}
                        placeholder="Brief description of the post"
                        rows={3}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="content">Content (Markdown supported)</Label>
                      <Textarea
                        id="content"
                        value={currentPost.content}
                        onChange={(e) => setCurrentPost({ ...currentPost, content: e.target.value })}
                        placeholder="Write your post content here..."
                        rows={12}
                        className="font-mono text-sm"
                      />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="date">Date</Label>
                        <Input
                          id="date"
                          type="date"
                          value={currentPost.date}
                          onChange={(e) => setCurrentPost({ ...currentPost, date: e.target.value })}
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="readTime">Read Time</Label>
                        <Input
                          id="readTime"
                          value={currentPost.readTime}
                          onChange={(e) => setCurrentPost({ ...currentPost, readTime: e.target.value })}
                          placeholder="e.g., 5 min read"
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="tags">Tags</Label>
                      <div className="flex gap-2">
                        <Input
                          id="tags"
                          value={tagInput}
                          onChange={(e) => setTagInput(e.target.value)}
                          onKeyPress={(e) => e.key === "Enter" && (e.preventDefault(), handleAddTag())}
                          placeholder="Add a tag and press Enter"
                        />
                        <Button type="button" onClick={handleAddTag} variant="outline">
                          Add
                        </Button>
                      </div>
                      <div className="flex flex-wrap gap-2 mt-2">
                        {currentPost.tags?.map((tag) => (
                          <Badge key={tag} variant="secondary" className="gap-1">
                            {tag}
                            <button onClick={() => handleRemoveTag(tag)} className="ml-1 hover:text-destructive">
                              ×
                            </button>
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <div className="flex gap-3 pt-4">
                      <Button onClick={handleSave} className="gap-2">
                        <Save className="h-4 w-4" />
                        Save Post
                      </Button>
                      <Button variant="outline" onClick={() => setIsEditing(false)}>
                        Cancel
                      </Button>
                    </div>
                  </div>
                </Card>
              )}

              <div className="space-y-4">
                <h2 className="text-2xl font-bold">All Posts</h2>
                {posts.map((post) => (
                  <Card key={post.id} className="p-6">
                    <div className="flex justify-between items-start gap-4">
                      <div className="flex-1 space-y-2">
                        <h3 className="text-xl font-semibold">{post.title}</h3>
                        <p className="text-sm text-muted-foreground">{post.excerpt}</p>
                        <div className="flex flex-wrap gap-2">
                          {post.tags.map((tag) => (
                            <Badge key={tag} variant="outline" className="text-xs">
                              {tag}
                            </Badge>
                          ))}
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => {
                            setCurrentPost(post)
                            setIsEditing(true)
                          }}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          className="text-destructive hover:text-destructive bg-transparent"
                          onClick={() => {
                            if (confirm("Are you sure you want to delete this post?")) {
                              console.log("Deleting post:", post.id)
                              alert("Post deleted! (Demo only)")
                            }
                          }}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
